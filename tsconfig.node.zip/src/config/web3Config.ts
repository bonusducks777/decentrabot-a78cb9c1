
// This file is kept for backward compatibility
// The actual configuration has been moved to RainbowKitProvider.tsx
import { config } from "@/components/RainbowKitProvider";

export { config };
